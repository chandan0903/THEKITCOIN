using Newtonsoft.Json;

namespace TheKitCoinApi.Models
{
    public class XpubGap
    {
        [JsonProperty("gap")]
        public int Gap { get; private set; }
    }
}