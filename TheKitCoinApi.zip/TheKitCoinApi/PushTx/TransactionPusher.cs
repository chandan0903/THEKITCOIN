using System;
using System.Threading.Tasks;
using TheKitCoinApi.Client;

namespace TheKitCoinApi.PushTx
{
   
    public class TransactionPusher
    {
        private readonly IHttpClient httpClient;
        public TransactionPusher()
        {
            httpClient = new BlockchainHttpClient();
        }
        public TransactionPusher(IHttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

     
        public async Task PushTransactionAsync(string transactionString)
        {
            if (string.IsNullOrWhiteSpace(transactionString))
            {
                throw new ArgumentNullException(nameof(transactionString));
            }

            await httpClient.PostAsync<string, object>("pushtx", transactionString, multiPartContent: true);
        }
    }
}
