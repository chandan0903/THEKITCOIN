using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TheKitCoinApi.Client;
using TheKitCoinApi.Models;

namespace TheKitCoinApi.Statistics
{
	
	public class StatisticsExplorer
	{
		private readonly IHttpClient httpClient;
		public StatisticsExplorer()
		{
			httpClient = new BlockchainHttpClient("https://thekitcoin.com/api");
		}
		internal StatisticsExplorer(IHttpClient httpClient)
		{
			this.httpClient = httpClient;
		}

	
		public async Task<StatisticsResponse> GetStatsAsync()
		{
            var queryString = new QueryString();
            queryString.Add("format","json");
			return await httpClient.GetAsync<StatisticsResponse>("stats", queryString);
		}

       
        public async Task<ChartResponse> GetChartAsync(string chartType, string timespan = null, string rollingAverage = null)
        {
            var queryString = new QueryString();
            queryString.Add("format","json");
            if (timespan != null)
            {
                queryString.Add("timespan", timespan);
            }
            if (rollingAverage != null)
            {
                queryString.Add("rollingAverage", rollingAverage);
            }
            try
            {
                return await httpClient.GetAsync<ChartResponse>("charts/" + chartType, queryString);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("No chart with this name"))
                {
                    throw new ArgumentOutOfRangeException(nameof(chartType), "This chart name does not exist");
                }
                if (ex.Message.Contains("Could not parse timestring"))
                {
                    throw new ArgumentOutOfRangeException(nameof(timespan), "Incorrect timespan format");
                }
                throw;
            }
        }

             public async Task<IDictionary<string,int>> GetPoolsAsync(int timespan = 4)
        {
            if (timespan < 1 || timespan > 10)
            {
                throw new ArgumentOutOfRangeException(nameof(timespan), "Timespan must be between 1 to 10");
            }

            var queryString = new QueryString();
            queryString.Add("format","json");
            queryString.Add("timespan", timespan + "days");

            return await httpClient.GetAsync<Dictionary<string,int>>("pools", queryString);
        }
	}
}
