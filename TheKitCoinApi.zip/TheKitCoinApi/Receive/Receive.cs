using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TheKitCoinApi.Client;
using TheKitCoinApi.Models;

namespace TheKitCoinApi.Receive
{
    public class Receive
    {
        private readonly IHttpClient httpClient;

        public Receive(IHttpClient httpClient = null)
        {
            this.httpClient = (httpClient == null)
                ? new BlockchainHttpClient("https://thekitcoin.com/api/v2")
                : httpClient;
        }

       
        public async Task<ReceivePaymentResponse> GenerateAddressAsync(string xpub, string callback, string key, int? gapLimit)
        {
            var queryString = new QueryString();
            queryString.Add("xpub", xpub);
            queryString.Add("callback", callback);
            queryString.Add("key", key);
            if (gapLimit.HasValue) { queryString.Add("gap_limit", gapLimit.ToString()); }

            try
            {
                return await httpClient.GetAsync<ReceivePaymentResponse>("receive", queryString);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Invalid xpub format"))
                {
                    throw new ArgumentException(nameof(xpub), "the xpub provided is invalid");
                }
                if (ex.Message.Contains("API Key is not valid"))
                {
                    throw new ArgumentException(nameof(key), "the api key provided is invalid");
                }
                throw;
            }
        }

     
        public async Task<XpubGap> CheckAddressGapAsync(string xpub, string key)
        {
            var queryString = new QueryString();
            queryString.Add("xpub", xpub);
            queryString.Add("key", key);

            try
            {
                return await httpClient.GetAsync<XpubGap>("receive/checkgap", queryString);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Invalid xpub format"))
                {
                    throw new ArgumentException(nameof(xpub), "the xpub provided is invalid");
                }
                if (ex.Message.Contains("API Key is not valid"))
                {
                    throw new ArgumentException(nameof(key), "the api key provided is invalid");
                }
                throw;
            }
        }

    
        public async Task<IEnumerable<CallbackLog>> GetCallbackLogsAsync(string callback, string key)
        {
            var queryString = new QueryString();
            queryString.Add("callback", callback);
            queryString.Add("key", key);

            try
            {
                return await httpClient.GetAsync<IEnumerable<CallbackLog>>("receive/callback_log", queryString);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("API Key is not valid"))
                {
                    throw new ArgumentException(nameof(key), "the api key provided is invalid");
                }
                throw;
            }
        }
    }
}