using System;
using System.Threading.Tasks;
using TheKitCoinApi.Client;
using TheKitCoinApi.Models;

namespace TheKitCoinApi.Wallet
{
 
    public class WalletCreator
    {
        private readonly IHttpClient httpClient;

        public WalletCreator()
        {
            httpClient = new BlockchainHttpClient();
        }

        public WalletCreator(IHttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

     
		public async Task<CreateWalletResponse> CreateAsync(string password, string privateKey = null, string label = null, string email = null)
		{
            if (string.IsNullOrWhiteSpace(password))
            {
                throw new ArgumentNullException(nameof(password));
            }
            if (string.IsNullOrWhiteSpace(httpClient.ApiCode))
            {
                throw new ArgumentNullException("Api code must be specified", innerException: null);
            }

            var request = new CreateWalletRequest {
                Password = password,
                ApiCode = httpClient.ApiCode,
                PrivateKey = privateKey,
                Label = label,
                Email = email
            };

            var newWallet = await httpClient.PostAsync<CreateWalletRequest, CreateWalletResponse>("api/v2/create/", request, contentType: "application/json");
            return newWallet;
		}
    }
}