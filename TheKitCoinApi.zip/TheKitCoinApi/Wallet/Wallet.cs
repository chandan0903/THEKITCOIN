﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TheKitCoinApi.Client;
using TheKitCoinApi.Models;
using TheKitCoinApi.Json;
using Newtonsoft.Json;

namespace TheKitCoinApi.Wallet
{
   
    public class Wallet
    {
        private readonly IHttpClient httpClient;
        private readonly string identifier;
        private readonly string password;
        private readonly string secondPassword;

       
        internal Wallet(IHttpClient httpClient, string identifier, string password, string secondPassword = null)
        {
            this.httpClient = httpClient;
            this.identifier = identifier;
            this.password = password;
            this.secondPassword = secondPassword;
        }

        
        public async Task<PaymentResponse> SendAsync(string toAddress, BitcoinValue amount,
            string fromAddress = null, BitcoinValue fee = null)
        {
            if (string.IsNullOrWhiteSpace(toAddress))
            {
                throw new ArgumentNullException(nameof(toAddress));
            }
            if (amount.GetBtc() <= 0)
            {
                throw new ArgumentException("Amount sent must be greater than 0", nameof(amount));
            }

            QueryString queryString = new QueryString();
            queryString.Add("password", password);
            queryString.Add("to", toAddress);
            queryString.Add("amount", amount.Satoshis.ToString());
            if (!string.IsNullOrWhiteSpace(secondPassword))
            {
                queryString.Add("second_password", secondPassword);
            }
            if (!string.IsNullOrWhiteSpace(fromAddress))
            {
                queryString.Add("from", fromAddress);
            }
            if (fee != null)
            {
                queryString.Add("fee", fee.ToString());
            }

            string route = $"merchant/{identifier}/payment";

            PaymentResponse paymentResponse = await httpClient.GetAsync<PaymentResponse>(route, queryString);
            return paymentResponse;
        }

       
        public async Task<PaymentResponse> SendManyAsync(Dictionary<string, BitcoinValue> recipients,
            string fromAddress = null, BitcoinValue fee = null)
        {
            if (recipients == null || recipients.Count == 0)
            {
                throw new ArgumentException("Sending bitcoin from your wallet requires at least one receipient.", nameof(recipients));
            }

            QueryString queryString = new QueryString();
            queryString.Add("password", password);
            string recipientsJson = JsonConvert.SerializeObject(recipients, Formatting.None, new BitcoinValueJsonConverter());
            queryString.Add("recipients", recipientsJson);
            if (!string.IsNullOrWhiteSpace(secondPassword))
            {
                queryString.Add("second_password", secondPassword);
            }
            if (!string.IsNullOrWhiteSpace(fromAddress))
            {
                queryString.Add("from", fromAddress);
            }
            if (fee != null)
            {
                queryString.Add("fee", fee.ToString());
            }

            string route = $"merchant/{identifier}/sendmany";

            PaymentResponse paymentResponse = await httpClient.GetAsync<PaymentResponse>(route, queryString);

            return paymentResponse;
        }

   
        public async Task<BitcoinValue> GetBalanceAsync()
        {
            QueryString queryString = BuildBasicQueryString();
            string route = $"merchant/{identifier}/balance";
            BitcoinValue bitcoinValue = await httpClient.GetAsync<BitcoinValue>(route, queryString);
            return bitcoinValue;
        }

    
        public async Task<List<WalletAddress>> ListAddressesAsync()
        {
            QueryString queryString = BuildBasicQueryString();

            string route = $"merchant/{identifier}/list";

            List<WalletAddress> addressList = await httpClient.GetAsync<List<WalletAddress>>(route, queryString, WalletAddress.DeserializeMultiple);
            return addressList;
        }

     
        public async Task<WalletAddress> GetAddressAsync(string address)
        {
            if (string.IsNullOrWhiteSpace(address))
            {
                throw new ArgumentNullException(nameof(address));
            }
            QueryString queryString = BuildBasicQueryString();
            queryString.Add("address", address);

            string route = $"merchant/{identifier}/address_balance";
            WalletAddress addressObj = await httpClient.GetAsync<WalletAddress>(route, queryString);
            return addressObj;
        }

     
        public async Task<WalletAddress> NewAddressAsync(string label = null)
        {
            QueryString queryString = BuildBasicQueryString();
            if (label != null)
            {
                queryString.Add("label", label);
            }
            string route = $"merchant/{identifier}/new_address";
            WalletAddress addressObj = await httpClient.GetAsync<WalletAddress>(route, queryString);
            return addressObj;
        }

   
        public async Task<string> ArchiveAddressAsync(string address)
        {
            if (string.IsNullOrWhiteSpace(address))
            {
                throw new ArgumentNullException(nameof(address));
            }
            QueryString queryString = BuildBasicQueryString();
            queryString.Add("address", address);

            string route = $"merchant/{identifier}/archive_address";
            return await httpClient.GetAsync<string>(route, queryString, WalletAddress.DeserializeArchived);
        }

       
        public async Task<string> UnarchiveAddressAsync(string address)
        {
            if (address == null)
            {
                throw new ArgumentNullException(nameof(address));
            }
            QueryString queryString = BuildBasicQueryString();
            queryString.Add("address", address);

            string route = $"merchant/{identifier}/unarchive_address";
            return await httpClient.GetAsync<string>(route, queryString, WalletAddress.DeserializeUnArchived);
        }

        private QueryString BuildBasicQueryString()
        {
            QueryString queryString = new QueryString();

            queryString.Add("password", password);
            if (secondPassword != null)
            {
                queryString.Add("second_password", secondPassword);
            }

            return queryString;
        }
	}
}