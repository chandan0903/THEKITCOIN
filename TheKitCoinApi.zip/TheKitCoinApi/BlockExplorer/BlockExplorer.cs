using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TheKitCoinApi.Client;
using TheKitCoinApi.Json;
using TheKitCoinApi.Models;

namespace TheKitCoinApi.BlockExplorer
{
	
	public class BlockExplorer
	{
		private readonly IHttpClient httpClient;
		public const int MAX_TRANSACTIONS_PER_REQUEST = 50;
        public const int MAX_TRANSACTIONS_PER_MULTI_REQUEST = 100;
        public const int DEFAULT_UNSPENT_TRANSACTIONS_PER_REQUEST = 250;

		public BlockExplorer()
		{
			httpClient  = new BlockchainHttpClient();
		}

		internal BlockExplorer(IHttpClient httpClient)
		{
			this.httpClient = httpClient;
		}

		
        [System.Obsolete("Deprecated. Get transaction by hash wherever possible.")]
		public async Task<Transaction> GetTransactionByIndexAsync(long index)
		{
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException(nameof(index), "Index must be a positive integer");
			}

			return await GetTransactionAsync(index.ToString());
		}

		
		public async Task<Transaction> GetTransactionByHashAsync(string hash)
		{
			if (string.IsNullOrWhiteSpace(hash))
			{
				throw new ArgumentNullException(nameof(hash));
			}

			return await GetTransactionAsync(hash);
		}

        private async Task<Transaction> GetTransactionAsync(string hashOrIndex)
		{
			if (string.IsNullOrWhiteSpace(hashOrIndex))
			{
				throw new ArgumentNullException(nameof(hashOrIndex));
			}

			return await httpClient.GetAsync<Transaction>("rawtx/" + hashOrIndex);
		}

	
        [System.Obsolete("Deprecated. Get block by hash wherever possible.")]
		public async Task<Block> GetBlockByIndexAsync(long index)
		{
			if (index < 0)
			{
				throw new ArgumentOutOfRangeException(nameof(index), "Index must be greater than zero");
			}
			return await GetBlockAsync(index.ToString());
		}

	
		public async Task<Block> GetBlockByHashAsync(string hash)
		{
			if (string.IsNullOrWhiteSpace(hash))
			{
				throw new ArgumentNullException(nameof(hash));
			}
			return await GetBlockAsync(hash);
		}

        private async Task<Block> GetBlockAsync(string hashOrIndex)
		{
			if (string.IsNullOrWhiteSpace(hashOrIndex))
			{
				throw new ArgumentNullException(nameof(hashOrIndex));
			}
			return await httpClient.GetAsync<Block>("rawblock/" + hashOrIndex, customDeserialization: Block.Deserialize);
		}

      
        public async Task<Address> GetBase58AddressAsync(string address, int limit = MAX_TRANSACTIONS_PER_REQUEST,
                                                            int offset = 0, FilterType filter = FilterType.RemoveUnspendable)
        {
            return await GetAddressAsync(address, limit, offset, filter);
        }

    
        public async Task<Address> GetHash160AddressAsync(string address, int limit = MAX_TRANSACTIONS_PER_REQUEST,
                                                            int offset = 0, FilterType filter = FilterType.RemoveUnspendable)
        {
            return await GetAddressAsync(address, limit, offset, filter);
        }

		private async Task<Address> GetAddressAsync(string address, int limit, int offset, FilterType ft)
		{
			if (string.IsNullOrWhiteSpace(address))
			{
				throw new ArgumentNullException(address);
			}
            if (limit < 1 || limit > MAX_TRANSACTIONS_PER_REQUEST)
            {
                throw new ArgumentOutOfRangeException(nameof(limit), "transaction limit must be greater than 0 and smaller than " + MAX_TRANSACTIONS_PER_REQUEST);
            }
            if (offset < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(offset), "offset must be equal to or greater than 0");
            }

            var queryString = new QueryString();
            queryString.Add("limit", limit.ToString());
            queryString.Add("offset", offset.ToString());
            queryString.Add("filter", ((int)ft).ToString());
			queryString.Add("format", "json");

            try
            {
                return await httpClient.GetAsync<Address>("address/" + address, queryString);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("does not validate") || ex.Message.Contains("too short"))
                {
                    throw new ArgumentException(nameof(address), "address provided is invalid");
                }
                throw;
            }
		}

      
        public async Task<Xpub> GetXpub(string xpub, int limit = MAX_TRANSACTIONS_PER_MULTI_REQUEST,
                                        int offset = 0, FilterType filter = FilterType.RemoveUnspendable)
        {
            if (string.IsNullOrWhiteSpace(xpub))
			{
				throw new ArgumentNullException(xpub);
			}
            if (limit < 1 || limit > MAX_TRANSACTIONS_PER_MULTI_REQUEST)
            {
                throw new ArgumentOutOfRangeException(nameof(limit), "transaction limit must be greater than 0 and smaller than " + MAX_TRANSACTIONS_PER_MULTI_REQUEST);
            }
            if (offset < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(offset), "offset must be equal to or greater than 0");
            }

            var queryString = new QueryString();

            queryString.Add("active", xpub);
            queryString.Add("limit", limit.ToString());
            queryString.Add("offset", offset.ToString());
            queryString.Add("filter", ((int)filter).ToString());
			queryString.Add("format", "json");

            try
            {
                return await httpClient.GetAsync<Xpub>("multiaddr", queryString, Xpub.Deserialize);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Invalid Bitcoin Address"))
                {
                    throw new ArgumentException(nameof(xpub), "the xpub provided is invalid");
                }
                throw;
            }
        }

        
        public async Task<MultiAddress> GetMultiAddressAsync(IEnumerable<string> addressList, int limit = MAX_TRANSACTIONS_PER_MULTI_REQUEST,
                                                            int offset = 0, FilterType filter = FilterType.RemoveUnspendable)
        {
            if (addressList == null || addressList.Count() == 0)
			{
				throw new ArgumentNullException("No addresses provided");
			}
            if (limit < 1 || limit > MAX_TRANSACTIONS_PER_MULTI_REQUEST)
            {
                throw new ArgumentOutOfRangeException(nameof(limit), "transaction limit must be greater than 0 and smaller than " + MAX_TRANSACTIONS_PER_MULTI_REQUEST);
            }
            if (offset < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(offset), "offset must be equal to or greater than 0");
            }

            var queryString = new QueryString();
            var addressQuery = String.Join("|", addressList);

            queryString.Add("active", addressQuery);
            queryString.Add("limit", limit.ToString());
            queryString.Add("offset", offset.ToString());
            queryString.Add("filter", ((int)filter).ToString());
			queryString.Add("format", "json");

            try
            {
                return await httpClient.GetAsync<MultiAddress>("multiaddr", queryString);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Invalid Bitcoin Address"))
                {
                    throw new ArgumentException(nameof(addressQuery), "one or more addresses provided are invalid");
                }
                throw;
            }
        }

	
		public async Task<ReadOnlyCollection<Block>> GetBlocksAtHeightAsync(long height)
		{
			if (height < 0)
			{
				throw new ArgumentOutOfRangeException(nameof(height), "Block height must be greater than or equal to zero");
			}
			var queryString = new QueryString();
			queryString.Add("format", "json");

			return await httpClient.GetAsync("block-height/" + height, queryString, Block.DeserializeMultiple);
		}

		
		public async Task<ReadOnlyCollection<UnspentOutput>> GetUnspentOutputsAsync(IEnumerable<string> addressList, int limit = DEFAULT_UNSPENT_TRANSACTIONS_PER_REQUEST, int confirmations = 0)
		{
			if (addressList == null || addressList.Count() == 0)
			{
				throw new ArgumentNullException("No addresses provided");
			}
            if (limit < 1 || limit > DEFAULT_UNSPENT_TRANSACTIONS_PER_REQUEST)
            {
                throw new ArgumentOutOfRangeException(nameof(limit), "transaction limit must be greater than 0 and smaller than " + DEFAULT_UNSPENT_TRANSACTIONS_PER_REQUEST);
            }
            if (confirmations < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(confirmations), "confirmations must be equal to or greater than 0");
            }

			var queryString = new QueryString();
			var addressQuery = String.Join("|", addressList);

            queryString.Add("active", addressQuery);
            queryString.Add("limit", limit.ToString());
            queryString.Add("confirmations", confirmations.ToString());
			queryString.Add("format", "json");
			try
			{
				return await httpClient.GetAsync("unspent", queryString, UnspentOutput.DeserializeMultiple);
			}
			catch (Exception ex)
			{
				// Currently the API throws an internal error if there are no free outputs to spend. No free outputs is
				// a legitimate response. Therefore, until we fix this issue, we are circumventing this by returning an empty list
				if (ex.Message.Contains("outputs to spend"))
				{
					return new ReadOnlyCollection<UnspentOutput>(new List<UnspentOutput>());
				}
                if (ex.Message.Contains("Invalid Bitcoin Address"))
                {
                    throw new ArgumentException(nameof(addressQuery), "one or more addresses provided are invalid");
                }
				throw;
			}
		}

		public async Task<LatestBlock> GetLatestBlockAsync()
		{
			return await httpClient.GetAsync<LatestBlock>("latestblock");
		}

		
		public async Task<ReadOnlyCollection<Transaction>> GetUnconfirmedTransactionsAsync()
		{
			var queryString = new QueryString();
			queryString.Add("format", "json");

			return await httpClient.GetAsync("unconfirmed-transactions", queryString, Transaction.DeserializeMultiple);
		}

		
		public async Task<ReadOnlyCollection<SimpleBlock>> GetBlocksByDateTimeAsync(DateTime dateTime)
		{
			DateTimeOffset utcDate = DateTime.SpecifyKind(dateTime, DateTimeKind.Utc);
			var unixMillis = (long)(utcDate.ToUnixTimeMilliseconds());

			if (unixMillis < UnixDateTimeJsonConverter.GenesisBlockUnixMillis)
			{
				throw new ArgumentOutOfRangeException(nameof(dateTime), "Date must be greater than or equal to the genesis block creation date (2009-01-03T18:15:05+00:00)");
			}
			if (dateTime.ToUniversalTime() > DateTime.UtcNow)
			{
				throw new ArgumentOutOfRangeException(nameof(dateTime), "Date must be in the past");
			}
			return await GetBlocksAsync(unixMillis.ToString());
		}

	
		public async Task<ReadOnlyCollection<SimpleBlock>> GetBlocksByTimestampAsync(long unixMillis)
		{
			if (unixMillis < UnixDateTimeJsonConverter.GenesisBlockUnixMillis)
			{
				throw new ArgumentOutOfRangeException(nameof(unixMillis), "Date must be greater than or equal to the genesis block creation date (2009-01-03T18:15:05+00:00)");
			}
			return await GetBlocksAsync(unixMillis.ToString());
		}

      
        public async Task<ReadOnlyCollection<SimpleBlock>> GetBlocksByPoolNameAsync(string poolName = "")
        {
            return await GetBlocksAsync(poolName);
        }

		
		private async Task<ReadOnlyCollection<SimpleBlock>> GetBlocksAsync(string poolNameOrTimestamp)
		{
			var queryString = new QueryString();
			queryString.Add("format", "json");

			ReadOnlyCollection<SimpleBlock> simpleBlocks = await httpClient.GetAsync("blocks/" + poolNameOrTimestamp, queryString, SimpleBlock.DeserializeMultiple);

			return simpleBlocks;
		}
	}
}