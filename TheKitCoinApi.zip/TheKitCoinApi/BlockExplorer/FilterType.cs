namespace TheKitCoinApi.BlockExplorer
{
    public enum FilterType
    {
        All = 4,
        ConfirmedOnly,
        RemoveUnspendable
    }
}